#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Collect TCP data received from any program (specifically the MoleNet setup) 
from the students of the IoT Course Arduino Lab. Data is collected
as folows.

- dumps received data as lines on terminal
- dumps received data as lines to a file
 
@author: Asanga Udugama (adu@comnets.uni-bremen.de)
@date:   Thu 17 Apr 12:11:39 2025

"""
import socket
import datetime
import os
import argparse
import time
import threading

def client_handler(conn, addr, fp, write_lock):
    
    ## handle the connection and get data
    while True:
        try:
            ## receive data
            data = conn.recv(1024)
            if not data:
                break
            msg = data.decode()
            msg = msg.strip()
            if len(msg) > 0:
                writestr = 'TCP: ' + datetime.datetime.today().strftime('%Y-%m-%d-%H:%M:%S') + ' - ' + addr[0] + ' - ' + msg
                writestr = writestr + '\n' if writestr.rfind('\n') == -1 else writestr

                with write_lock:

                    ## write to terminal
                    print(writestr, end='')

                    ## write to file
                    fp.write(writestr)
                    fp.flush()
                    os.fsync(fp)

        except:
            break
    
    ## close connection
    conn.close()

# Start the TCP server
def start_tcpserver():

    ## parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--bindaddress', help='IP address to bind to',
                        required=False, default='127.0.0.1')
    parser.add_argument('-p', '--bindport', type=int, help='TCP Port to bind to',
                        required=False, default=9999)
    args = parser.parse_args()

    ## create a lock to write to file and print
    write_lock = threading.Lock()
    
    ## create fresh output file to dump data
    filename = './tcp-' + datetime.datetime.today().strftime('%Y-%m-%d-%H-%M-%S') + '-data.txt'
    fp = open(filename, 'w')

    # console message
    print('TCP: Starting server...')
    print('TCP: Details ')
    print('TCP:   Socket ' + args.bindaddress + ':' + str(args.bindport))
    print('TCP:   File ' + filename)

    ## process each connection
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((args.bindaddress, args.bindport))
        server_socket.listen()
        
        while True:
            
            ## accept connections
            conn, addr = server_socket.accept()

            # start connection thread
            thread = threading.Thread(target=client_handler, args=(conn, addr, fp, write_lock))
            thread.start()

if __name__ == '__main__':
    start_tcpserver()
